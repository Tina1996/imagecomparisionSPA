import './App.css';
import PhotoListComponent from './Components/PhotoListComponent';

function App() {
  return (
    <div className="App">
        <PhotoListComponent />
    </div>
  );
}

export default App;
